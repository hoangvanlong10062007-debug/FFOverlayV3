package com.example.ffoverlayv3

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.graphics.Color
import android.view.Gravity

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 28, 28, 28)
            setBackgroundColor(Color.rgb(12, 19, 27))
        }
        val title = TextView(this).apply {
            text = "FF OVERLAY CONTROL V3.0"
            textSize = 21f
            setTextColor(Color.rgb(255, 181, 46))
            gravity = Gravity.CENTER
        }
        val info = TextView(this).apply {
            text = "Floating demo panel for Android\n\nThis app only displays an independent overlay. It does not modify Free Fire or control gameplay."
            textSize = 14f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(0, 24, 0, 24)
        }
        val permission = Button(this).apply { text = "1. Grant display-over-other-apps permission" }
        val start = Button(this).apply { text = "2. Start floating menu" }
        val stop = Button(this).apply { text = "Stop floating menu" }
        root.addView(title)
        root.addView(info)
        root.addView(permission)
        root.addView(start)
        root.addView(stop)
        setContentView(root)

        permission.setOnClickListener {
            if (!Settings.canDrawOverlays(this)) {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")))
            }
        }
        start.setOnClickListener {
            if (Settings.canDrawOverlays(this)) {
                startService(Intent(this, OverlayService::class.java).setAction(OverlayService.ACTION_SHOW))
                finish()
            } else {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")))
            }
        }
        stop.setOnClickListener {
            stopService(Intent(this, OverlayService::class.java))
        }
    }
}
