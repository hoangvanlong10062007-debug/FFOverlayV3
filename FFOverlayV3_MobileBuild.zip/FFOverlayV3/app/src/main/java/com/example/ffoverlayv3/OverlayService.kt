package com.example.ffoverlayv3

import android.app.Service
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class OverlayService : Service() {
    companion object { const val ACTION_SHOW = "SHOW_OVERLAY" }

    private lateinit var wm: WindowManager
    private var bubble: TextView? = null
    private var panel: LinearLayout? = null
    private var bubbleParams: WindowManager.LayoutParams? = null
    private var panelParams: WindowManager.LayoutParams? = null
    private var panelVisible = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startAsForegroundService()
        if (bubble == null) showBubble()
        return START_STICKY
    }

    private fun startAsForegroundService() {
        val channelId = "ff_overlay_demo"
        val manager = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId, "Floating demo menu", NotificationManager.IMPORTANCE_LOW
            )
            manager.createNotificationChannel(channel)
        }
        val notification = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Notification.Builder(this, channelId)
                .setContentTitle("FF Overlay Demo is running")
                .setContentText("Tap the floating FF bubble to open the demo panel.")
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .build()
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(this)
                .setContentTitle("FF Overlay Demo is running")
                .setContentText("Floating demo panel is active.")
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .build()
        }
        startForeground(1001, notification)
    }

    private fun params(): WindowManager.LayoutParams =
        WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = 24; y = 180 }

    private fun showBubble() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val b = TextView(this).apply {
            text = "FF"
            textSize = 16f
            setTextColor(Color.BLACK)
            gravity = Gravity.CENTER
            setBackgroundColor(Color.rgb(255, 181, 46))
            setPadding(18, 14, 18, 14)
            elevation = 12f
        }
        val p = params()
        bubbleParams = p
        b.setOnTouchListener(object : View.OnTouchListener {
            var downX = 0
            var downY = 0
            var startX = 0
            var startY = 0
            var moved = false
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> {
                        downX = e.rawX.toInt(); downY = e.rawY.toInt()
                        startX = p.x; startY = p.y; moved = false
                        return true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = e.rawX.toInt() - downX
                        val dy = e.rawY.toInt() - downY
                        if (kotlin.math.abs(dx) + kotlin.math.abs(dy) > 8) moved = true
                        p.x = startX + dx; p.y = startY + dy
                        wm.updateViewLayout(b, p)
                        return true
                    }
                    MotionEvent.ACTION_UP -> {
                        if (!moved) togglePanel()
                        return true
                    }
                }
                return false
            }
        })
        bubble = b
        wm.addView(b, p)
    }

    private fun togglePanel() {
        if (panelVisible) {
            panel?.let { try { wm.removeView(it) } catch (_: Exception) {} }
            panel = null; panelVisible = false
            return
        }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 16, 18, 16)
            setBackgroundColor(Color.rgb(17, 27, 38))
            elevation = 18f
        }
        val heading = TextView(this).apply {
            text = "CONTROL CENTER  V3.0"
            textSize = 15f
            setTextColor(Color.rgb(255, 181, 46))
            setPadding(4, 4, 4, 12)
        }
        box.addView(heading)
        listOf("Aim Assist · demo", "ESP Overlay · demo", "Speed Boost · demo",
            "FPS Display · demo", "Crosshair · demo").forEach { label ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
            }
            val text = TextView(this).apply {
                this.text = label
                textSize = 12f
                setTextColor(Color.WHITE)
                setPadding(4, 10, 18, 10)
            }
            val toggle = android.widget.Switch(this).apply {
                isChecked = false
                buttonTintList = android.content.res.ColorStateList.valueOf(Color.rgb(255,181,46))
            }
            row.addView(text, LinearLayout.LayoutParams(0, -2, 1f))
            row.addView(toggle)
            box.addView(row)
        }
        val close = Button(this).apply {
            text = "CLOSE"
            setOnClickListener { togglePanel() }
        }
        box.addView(close)
        val pp = params().apply {
            x = 20; y = 250
            flags = WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
        }
        panelParams = pp
        panel = box
        wm.addView(box, pp)
        panelVisible = true
    }

    override fun onDestroy() {
        panel?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        bubble?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        panel = null; bubble = null
        super.onDestroy()
    }
}
