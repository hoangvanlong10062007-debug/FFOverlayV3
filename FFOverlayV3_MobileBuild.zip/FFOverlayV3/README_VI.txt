FF OVERLAY CONTROL V3.0 — ANDROID STUDIO PROJECT

Đây là mã nguồn dự án Android cho một nút nổi và bảng điều khiển demo.
Các công tắc chỉ đổi trạng thái hiển thị; ứng dụng KHÔNG can thiệp Free Fire,
không đọc màn hình game, không tự động thao tác và không sửa dữ liệu game.

CÁCH MỞ VÀ BUILD APK
1. Cài Android Studio trên máy tính.
2. Giải nén ZIP.
3. Android Studio > Open > chọn thư mục FFOverlayV3.
4. Chờ Gradle Sync hoàn tất.
5. Chọn Build > Build Bundle(s) / APK(s) > Build APK(s).
6. APK debug thường nằm tại app/build/outputs/apk/debug/app-debug.apk.

CÁCH DÙNG TRÊN ĐIỆN THOẠI
1. Cài APK do Android Studio tạo.
2. Mở ứng dụng, cấp quyền "Display over other apps / Hiển thị trên ứng dụng khác".
3. Chọn Start floating menu.
4. Mở Free Fire; nút FF nổi có thể kéo thả. Chạm nút để mở/đóng bảng demo.
5. Dừng overlay bằng cách mở lại app và chọn Stop floating menu (hoặc buộc dừng ứng dụng).

LƯU Ý
- Android có thể giới hạn overlay hoặc tiến trình nền tùy hãng/phiên bản.
- Chỉ cấp quyền overlay cho ứng dụng bạn tự build và tin cậy.
- Dự án cần Android Studio/Android SDK để biên dịch; đây là source project,
  không phải APK đã biên dịch.
